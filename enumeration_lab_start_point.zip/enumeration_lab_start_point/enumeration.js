var Enumeration = function() {}

Enumeration.prototype = {

  find: function(){
    // code here that makes the test pass!
  }

}


module.exports = Enumeration;